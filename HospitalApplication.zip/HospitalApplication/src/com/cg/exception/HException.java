package com.cg.exception;
public class HException extends Exception 
{
	private static final long serialVersionUID = 726264577455921591L;

	public HException(String message) 
	{
		
		super(message);
	}
}
