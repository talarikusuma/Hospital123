package com.cg.dao;

public interface QuickMapper {

	//public static final String RETRIVE_ALL_QUERY="SELECT PatientName,PatientAge,PatientPhoneNumber,Description,ConsultationDate FROM Patient_Details";
	public static final String VIEW_PATIENT_DETAILS_QUERY="SELECT PatientName,PatientAge,PatientPhoneNumber,Description,ConsultationDate FROM  Patient_Details WHERE  PatientId=?";
	public static final String INSERT_QUERY="INSERT INTO Patient_Details VALUES(PatientId_sequence.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String PATIENTID_QUERY_SEQUENCE="SELECT PatientId_sequence.CURRVAL FROM DUAL";
}
