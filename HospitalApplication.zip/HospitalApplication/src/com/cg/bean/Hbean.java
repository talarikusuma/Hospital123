package com.cg.bean;

import java.time.LocalDate;
import java.util.Date;

public class Hbean {
	int PatientId;
	String PatientName;
	int PatientAge;
	long PatientPhoneNumber;
	String Description;
	LocalDate ConsultationDate;
	public int getPatientId() {
		return PatientId;
	}
	public void setPatientId(int patientId) {
		PatientId = patientId;
	}
	public String getPatientName() {
		return PatientName;
	}
	public void setPatientName(String patientName) {
		PatientName = patientName;
	}
	public int getPatientAge() {
		return PatientAge;
	}
	public void setPatientAge(int patientAge) {
		PatientAge = patientAge;
	}
	public long getPatientPhoneNumber() {
		return PatientPhoneNumber;
	}
	public void setPatientPhoneNumber(long patientPhoneNumber) {
		PatientPhoneNumber = patientPhoneNumber;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public LocalDate getConsultationDate() {
		return ConsultationDate;
	}
	@Override
	public String toString() {
		return "Hbean [ PatientName=" +  getPatientName() + ", PatientAge=" + getPatientAge()
				+ ", PatientPhoneNumber=" + getPatientPhoneNumber() + ", Description=" + getDescription() + ", ConsultationDate="
				+ getConsultationDate() + "]";
	}
	public void setConsultationDate(LocalDate localDate) {
		ConsultationDate = localDate;
	}

}
